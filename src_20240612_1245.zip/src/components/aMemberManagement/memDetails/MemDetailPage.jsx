import React from "react";
import MemDetailLayout from "./MemDetailLayout";

const MemDetailPage = () => {
  return <MemDetailLayout />;
};

export default MemDetailPage;
