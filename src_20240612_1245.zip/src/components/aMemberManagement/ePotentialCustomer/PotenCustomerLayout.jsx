// src/components/aMemberManagement/ePotentialCustomer/PotenCustomerLayout.jsx
import React from 'react';

const PotenCustomerLayout = () => {
  return (
    <div>
      <h1>회원상담관리</h1>
      {/* 추가적인 컴포넌트와 기능을 여기에 작성 */}
    </div>
  );
};

export default PotenCustomerLayout;
