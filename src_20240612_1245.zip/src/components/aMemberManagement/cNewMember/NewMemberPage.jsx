import React from "react";
import MemberLayout from "./MemberLayout"; // MemberLayout import

const NewMemberPage = () => {
  return (
    <div>
      <MemberLayout /> {/* MemberLayout 불러오기 */}
    </div>
  );
};

export default NewMemberPage;
