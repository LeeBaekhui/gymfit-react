function App() {
  const handleOnSubmit = () => {
    // onSubmitProc function logic here
  };
  return (
<h1>대여상품관리</h1>
  );
}

export default App;


