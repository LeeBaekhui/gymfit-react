// 경로: src\components\gymSetting\gymSettingDetails\gymlockerSetting\LockerProductsView.jsx

import React from 'react';

const LockerProductsView = () => {
  return (
    <div>
      <h2>락커 현황</h2>
      {/* Your component content */}
    </div>
  );
};

export default LockerProductsView;